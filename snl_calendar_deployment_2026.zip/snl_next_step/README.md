# Sunday Night Lights calendar synchronization — deployment candidate

**Playoff-aware deployment package (not yet deployed).**

The workflow downloads the latest OneDrive workbook every 15 minutes (GitHub schedules may be delayed), generates six team feeds and deploys them to GitHub Pages. It uses existing `MS_CLIENT_ID` and `MSAL_CACHE` GitHub secrets. The workbook itself is never published.

## Important before deploying

1. The generator now includes score-driven playoff progression, conditional Game 3, and safe placeholders before seeding/matchups are known. A random draw that remains unresolved leaves the seeds pending rather than guessing.
2. A permanent `reference/game_uids.json` maps all 60 original Master Schedule rows to existing published UIDs. Date/time/diamond edits keep the same UID. Do not reorder or insert rows in the Master Schedule without updating the registry.
3. GitHub Pages must be set to **GitHub Actions** as its publishing source. Disable any conflicting Pages deployment workflow.
4. `MSAL_CACHE` is a fixed secret; Microsoft may rotate refresh tokens. Unattended operation will eventually require token-cache persistence or reauthorization.
5. GitHub Actions can run with your phone off; calendar clients (including Google Calendar) refresh subscribed feeds on their own schedule, not every 15 minutes.

## Contents

- `.github/workflows/sync-calendars.yml` — scheduled workflow and Pages deployment
- `scripts/download_onedrive.py` — authenticated workbook download
- `scripts/generate_calendars.py` — six regular-season feeds
- `reference/*.ics` — previously issued calendar files for UID matching

Run locally: `python scripts/generate_calendars.py 'SNL Fall 26.xlsx' --output site --reference reference`

**Deployment requires GitHub Pages to be configured for GitHub Actions and the existing MSAL secrets to remain valid.**

## Playoff engine milestone (not deployed)

`scripts/playoff_engine.py` implements score-driven best-of-three series results and playoff advancement using the Master Schedule row numbers. It correctly distinguishes potential, required, completed, and unnecessary Game 3s, and reseeds the quarterfinal winners for the semifinals. `scripts/test_playoffs.py` checks these cases without changing the source workbook.

Run `python scripts/test_playoffs.py` from the package root. The playoff engine is deliberately **not yet wired into** `generate_calendars.py` because regular-season standings tiebreakers and official random draws must be resolved first; publishing guesses could assign the wrong teams. The generated feeds remain regular-season-only until that integration is complete.

## Deployment

In your existing Codespaces terminal, unzip this package into the root of the repository, preserving `.github/workflows`, `scripts`, and `reference`. Do not copy the containing `snl_next_step` directory itself. Then `git add .github/workflows/sync-calendars.yml scripts reference && git commit -m "Publish playoff-aware team calendars" && git push`. Under repository Settings → Pages, select GitHub Actions as the source. Manually run Sync SNL Calendars in Actions and inspect the resulting GitHub Pages website. **Do not publish until any conflicting Pages workflow is disabled.**

The Microsoft MSAL refresh token in `MSAL_CACHE` is not persisted back to secrets by the workflow; future reauthentication may be required. Calendar apps control their own subscription refresh frequency.
